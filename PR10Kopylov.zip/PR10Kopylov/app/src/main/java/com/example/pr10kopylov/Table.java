package com.example.pr10kopylov;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Table extends AppCompatActivity implements View.OnClickListener {
    ImageButton Back;
    Button Borch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table);
        Back = findViewById(R.id.imageButton3);
        Back.setOnClickListener(this);
        Borch = findViewById(R.id.button11);
        Borch.setOnClickListener(this);
    }
    @Override
    public void onClick(View v){
        switch (v.getId()){
            case R.id.button11:
                startActivity(new Intent(this,ShowItem.class));
                break;
            case R.id.imageButton3:
                startActivity(new Intent(this,MainActivity.class));
                break;
        }
    }
}